function DV = Calc_DV(observed_streamflow, estimated_streamflow)

obs_vol = sum(observed_streamflow)*24*3600;
est_vol = sum(estimated_streamflow)*24*3600;

DV = (obs_vol - est_vol)/obs_vol*100;