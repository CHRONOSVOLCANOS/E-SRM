%% When using this code, please cite: 


% LAST UPDATED - 09/01/2024 @ 1.01 AM MDT
%% Expanded Snowmelt Runoff Model (E-SRM)

% Includes automated multi-year batch-processing, seasonal divider and
%   nested iterator algorithms.

% This code will read user-made specific hydrometeorological data and run the 
%   Snowmelt Runoff Model's (SRM) expansion into batch processing version 
%   (Expanded SRM (E-SRM)).

% This code is for E-SRM calibration.

% Input data required for rhis code:
%   1. Path and name of 'Base Parameters' file (in .xlsx format)
%   2. Path and name of 'Input Data' file (in .xlsx format)
%   3. Name of the output Excel file
%   4. Calibration period (years)

% Following data and example will demonstrate the use of this code.
%   1. Run the code.
%   2. Input path and name of the 'Base Parameters' Excel file.
%   3. Input path and name of the 'Input Data' Excel file.
%   4. Input the name of the output Excel file.
%   5. Input the calibration period. We used 11 years (water years 2000 - 2011).

%% INSTRUCTIONS FOR REVIEWERS

% Copy all the files from 'Figure_*_input' folder into current folder.

% I have already copied the right input data names.

% For Scenario 1, use 21 years for Calibration_period (insert value 21).
% For Scenario 2, use 11 years for calibration_period (insert value 11).

% You can change the output file name EXCEL.

% For recreating results, DO NOT CHANGE ANYTHING ELSE.

%% Model initialization by clearing all previous data
clear;
clc;

%% Get all input data from user before processing
Base_parameters = 'Canyon_Ferry_base_parameters_for_E-SRM.xlsx';%input('Please input the path and name of the Base Parameters Excel file.\n\n','s'); % Base parameters - includes zone number, zone area, fractional zone area, zone hypsometric elevation, reference elevation of one weather station for all zones and name of the weatehr station
Input_files_name = 'Canyon_Ferry_input_data_E-SRM.xlsx';%input('Please input the path and name of the Input Data Excel file.\n\n','s'); % Input variable data - includes Temperature, Precipitatipn, CDC (Fractional Snow Cover) and Streamflow
EXCEL = 'Scenario_2_CF_cal.xlsx';%input('Please provide the name of output Excel file (.xlsx): ','s'); % Output Excel file - includes NSE, DV, RMSE for each season within the timeline provided, and the total annual NSE, DV, RMSE, along with observed and simulated streamflow
Calibration_period = 11;%input('Please enter the calibration period (years): '); % Calibration period - how many years the E-SRM should be calibrated? (starting from first data point automatically)

%% Area and hypsometric elevations for all zones
Base_parameters_file = xlsread(Base_parameters); % Read Base Parameters file
A = Base_parameters_file(:,2);            % Areas of each zone, in km^2
A_fraction = Base_parameters_file(:,3); % Area of each zone as a fraction of total area
Hypso = Base_parameters_file(:,4);        % Hypsometric elevations of each zone
Eref = Base_parameters_file(:,5);      % Reference elevation of weather stations
zones = size(Base_parameters_file,1); % Number of zones

%% Input data for SRM
[T, text] = xlsread(Input_files_name,'T'); % Temperature from Input Data Excel file.
No_data_T = isnan(T(:,zones));
P = xlsread(Input_files_name,'P'); % Precipitation from Input Data Excel file.
No_data_P = isnan(P(:,zones));
CDC = xlsread(Input_files_name,'CDC'); % Fractional snow cover data from Excel file. Also reads all dates.
No_data_CDC = isnan(CDC(:,zones));
Dates = text(2:end,1); % Extracts dates as a vector.
Streamflow_observed = xlsread(Input_files_name,'Streamflow'); % Streamflow that will be used as the Observed streamflow for calculating NSE, DV and RMSE.
No_data_streamflow_observed = isnan(Streamflow_observed);
days = size(T,1); % Initialize total number of days in available data.
if size(T,1) == size(P,1) && size(T,1) == size(CDC,1) && size(T,1) == size(Streamflow_observed,1) % Making sure T, P, CDC and streamflow data have exactly same length
    if numel(No_data_T(No_data_T == 1)) == 0 && numel(No_data_P(No_data_P == 1)) == 0 && numel(No_data_CDC(No_data_CDC == 1)) == 0 && numel(No_data_streamflow_observed(No_data_streamflow_observed == 1)) == 0 % Making sure there is no cell with NaN values.
        %% Specifying local temperatures and precipitation vectors
        k = zeros(days,zones); % Initializing k. k is the recession coefficient based on parameters x and y. x and y will be calibrated using nested iterator later in the code.
        Results = string(zeros(16,11)); % Initializing Results matrix. This is the final data that will be output after simulation.
        Final_estimated_streamflow = zeros(days,1); % Initializing final streamflow. This streamflow is the FINAL streamflow after calculating seasonal and zonal streamflow.
        
        %% Specifying calibration period
        Starting_year = str2double(Dates{1}(end-3:end)); % Automatically assumes that the calibration starts on the first date. This will extract the year of that date.
        Ending_year = Starting_year+Calibration_period; % Canculates ending year based on starting year and calibation period.
        Available_timeline = str2double(Dates{end}(end-3:end)); % Calculates the total available timeline in the dataset.
        
        if Ending_year > Available_timeline % If ending year is past available dataset, STOP.
            fprintf('Calibration period exceeds the available timeline. Pausing...\n\n');
            pause;
        end
        
        j = 0; % Used for specifying the location of row for making the 'Results' table
        
        %% AUTOMATED BATCH PROCESSING ALGORITHM TO AUTOMATICALLY SIMULATE MULTIPLE YEARS
        for Current_year = Starting_year+1:1:Ending_year % Starting year + 1 is used because the year is a Water year, and starts on October 1 of previous year.
            %% INITIATE EXTARCTION OF ANNUAL STREAMFLOW
            Starting_date = ('10/1/'+string(Current_year-1)); % Beginning of water year - 10/01 of previous year
            Ending_date = ('9/30/'+string(Current_year)); % End of water year - 09/30 of current year
            Index_starting_date = find(string(Dates) == Starting_date);
            Index_ending_date = find(string(Dates) == Ending_date);
            Number_of_days = length(Index_starting_date:Index_ending_date);
            Start_of_Fall_day = find((string(Dates) == ('10/1/'+string(Current_year-1)))); % October 1 - originally September 21, used October 1 for model simplicity
            Start_of_Winter_day = find((string(Dates) == ('12/21/'+string(Current_year-1)))); % December 21
            Start_of_Spring_day = find((string(Dates) == ('3/21/'+string(Current_year)))); % March 21
            Start_of_Summer_day = find((string(Dates) == ('6/21/'+string(Current_year)))); % June 21
            Annual_observed_streamflow = 0.0; % Initializing observed annual streamflow for each year
            Annual_observed_streamflow = Streamflow_observed(Index_starting_date:Index_ending_date); % Automatically extract  annual streamflow for current year from total streamflow data
            Season = 1; % Season 1 is Fall, Season 2 is Winter, Season 3 is Spring, and Season 4 is Summer. Currently E-SRM simulation starts in Fall and ends in Summer.
            
            fprintf('\nSimulating the water year %d\n',Current_year);
            
            %% SEASONAL DIVIDER ALGORITHM
            while Season < 5 % Seasons 1-4 indicate Fall-Summer.
                if Season == 1 % Fall
                    Begining_of_season = Start_of_Fall_day; % Indexing for beginning of Fall
                    End_of_season = Start_of_Winter_day-1; % Indexing for end of Fall
                    Seasonal_days = End_of_season - (Begining_of_season-1); % Days in a season
                    Fall_streamflow = zeros(Seasonal_days,1); % Initialize total Fall streamflow
                    Fall_Qtot = zeros(Seasonal_days,zones); % Initialize zonal Fall streamflow
                    Baseflow = Streamflow_observed(Begining_of_season); % SRM needs a baseflow. We assume that the baseflow is the flow at the beginning of every season.
                    fprintf('\tFall\n');
                elseif Season == 2 % Winter
                    Begining_of_season = Start_of_Winter_day; % Indexing for beginning of Winter
                    End_of_season = Start_of_Spring_day-1; %  Indexing for end of Winter
                    Seasonal_days = End_of_season - (Begining_of_season-1); % Days in a season
                    Winter_streamflow = zeros(Seasonal_days,1); % Initialize total Winter streamflow
                    Winter_Qtot = zeros(Seasonal_days,zones); % Initialize zonal Winter streamflow
                    Baseflow = Streamflow_observed(Begining_of_season); % SRM needs a baseflow. We assume that the baseflow is the flow at the beginning of every season.
                    fprintf('\tWinter\n');
                elseif Season == 3 % Spring
                    Begining_of_season = Start_of_Spring_day; % Indexing for beginning of Spring
                    End_of_season = Start_of_Summer_day-1; %  Indexing for end of Spring
                    Seasonal_days = End_of_season - (Begining_of_season-1); % Days in a season
                    Spring_streamflow = zeros(Seasonal_days,1); % Initialize total Spring streamflow
                    Spring_Qtot = zeros(Seasonal_days,zones); % Initialize zonal Spring streamflow
                    Baseflow = Streamflow_observed(Begining_of_season); % SRM needs a baseflow. We assume that the baseflow is the flow at the beginning of every season.
                    fprintf('\tSpring\n');
                elseif Season == 4 % Summer
                    Begining_of_season = Start_of_Summer_day; % Indexing for beginning of Summer
                    End_of_season = Index_ending_date; %  Indexing for end of Summer
                    Seasonal_days = End_of_season - (Begining_of_season-1); % Days in a season
                    Summer_streamflow = zeros(Seasonal_days,1); % Initialize total Summer streamflow
                    Summer_Qtot = zeros(Seasonal_days,zones); % Initialize zonal Summer streamflow
                    Baseflow = Streamflow_observed(Begining_of_season); % SRM needs a baseflow. We assume that the baseflow is the flow at the beginning of every season.
                    fprintf('\tSummer\n');
                end
                Streamflow_observed_seasonal = 0.0; % Initializing annual observed streamflow
                T_observed_seasonal = 0.0;  % Initializing seasonal observed temperature
                P_observed_seasonal = 0.0; % Initializing seasonal observed precipitation
                CDC_observed_seasonal = 0.0; % Initializing seasonal fractional snow cover
                Streamflow_observed_seasonal = Streamflow_observed(Begining_of_season:End_of_season); % Extracting seasonal streamflow from raw data
                T_observed_seasonal = T(Begining_of_season:End_of_season,1:zones); % Extracting seasonal temperature for all zones from raw data
                P_observed_seasonal = P(Begining_of_season:End_of_season,1:zones); % Extracting seasonal precipitation for all zones from raw data
                CDC_observed_seasonal = CDC(Begining_of_season:End_of_season,1:zones); % Extracting seasonal fractional snow cover for all zones from raw data
                Tlocal_seasonal = zeros(Seasonal_days,zones); % Initializing local temperature for all zones
                Pn_seasonal = zeros(Seasonal_days,zones); % Initializing rain precipitation for all zones
                Ps_seasonal = zeros(Seasonal_days,zones); % Initializing snow precipitation for all zones
                Results(j+1,Season) = -1e3; % Initial condition - NSE = -1^3 (-1000)
                Qsnow = zeros(Seasonal_days,zones); % Initializing seasonal streamflow due to snowmelt for all zones
                Qrain = zeros(Seasonal_days,zones); % Initializing seasonal streamflow due to rainfall for all zones
                NSE_seasonal = 0.0; % Initializing NSE for calculation
                Best_streamflow = zeros(Seasonal_days,1); % Best seasonal streamflow after nested iterator (streamflow that gives maximum NSE when compared with observed streamflow)
                Best_Qtot = zeros(Seasonal_days,zones); % Best zonal seasonal streamflow (does not play any role in any calculations)
                k = zeros(Seasonal_days,zones); % Initializing seasonal k values for all zones
                
                %% NESTED ITERATOR ALGORITHM
                for Tcrit = 0 % Critical temperature (CURRENTLY CONSTANT)
                    for DegDay = 0.01:0.01:0.3 % Degree Day Factor
                        for RCsnow = 0.01:0.01:0.3 % Snowmelt Coefficient
                            for RCrain = 0.01:0.01:0.6 % Runoff Coefficient
                                for X = 1 % Recession COefficient X (CURRENTLY CONSTANT)
                                    for Y = 0.0:0.001:0.01 % Recession Coefficient Y
                                        for timelagP = 1 % Lag time for rain (CURRENTLY CONSTANT)
                                            for timelagS = 1 % Lag time for snowmelt (CURRENTLY CONSTANT)
                                                for Tlapse = 0.6 % Temperature lapse rate (CURRENTLY CONSTANT)
                                                    
                                                    % Initializing Qtot (Qtot is the streamflow obtained after SRM simulation
                                                    Qtot = zeros(Seasonal_days,zones); % Qtot HAS TO BE INSIDE INNERMOST NEST - needs to initialize for every parameter change
                                                    
                                                    if Season == 1 % If season if Fall, Qtot is the baseflow that is the raw streamflow on the first day of Fall
                                                        
                                                        % We calculate zonal Qtot by dividing the total streamflow by the areal fraction of that zone. 
                                                        %   We assume that the areal contribution of each zone will linearly affect streamflow contribution of each zone.
                                                        Qtot(1,:) = Baseflow*A_fraction;
                                                    else
                                                        Qtot(1,:) = Qtot_last_day; % For all other seasons, Qtot is the streamflow from the last day of the previous season.
                                                    end
                                                    
                                                    for season_day = 1:Seasonal_days-1 % Consider each seasonal day. (Seasonal_days-1) is used because we calculate the streamflow of the next day.
                                                        for zone = 1:zones % Consider each zone.
                                                            %% ORIGINAL SRM
                                                            
                                                            % Convert the temperature at weather station elevation to the temperature at the hypsometric elevation using temperature lapse rate.
                                                            %   If the elevation of the weather station is higher than hypsometric elevation of the zone, we go from higher elevation to lower elevtion. Therefore, the temperature should increase. 
                                                            %   If the elevation of the weather station is lower than hypsometric elevation of the zone, we go from lower elevation to higher elevtion. Therefore, the temperature should decrease.
                                                            Tlocal_seasonal(season_day,zone) = T_observed_seasonal(season_day,zone)+(Eref(zone)-Hypso(zone))*Tlapse/100; 
                                                           
                                                            if Tlocal_seasonal(season_day,zone) >= Tcrit % If temperature at the hypsometric elevation is higher than Critical temperature, precipitation is rain.
                                                                Pn_seasonal(season_day,zone) = P_observed_seasonal(season_day,zone);
                                                            else % If local temperature at the hypsometric elevation is lower than Critical temperature, precipitation is snow.
                                                                Ps_seasonal(season_day,zone) = P_observed_seasonal(season_day,zone);
                                                            end
                                                            
                                                            % CALCULATE Qsnow AND Qrain FOR EACH ZONE FOR EACH DAY
                                                            % Only calculate Qsnow and Qrain if the temperature at the hypsometric elevation is higher than Ctirical temperature.
                                                            if Tlocal_seasonal(season_day,zone) >= Tcrit  
                                                                Qsnow(season_day+1,zone)=RCsnow*DegDay*Tlocal_seasonal(season_day,zone).*CDC_observed_seasonal(season_day,zone).*A(zone)*((1e4)/(24*3600));
                                                                Qrain(season_day+1,zone)=RCrain.*Pn_seasonal(season_day,zone).*A(zone)*((1e4)/(24*3600));
                                                            end
                                                            
                                                            % calculating the recession coefficient with uper limit of 1 (k cannot go above 1)
                                                            if (X*Qtot(season_day,zone)^(-Y))> 0.99
                                                                k((season_day+1),zone)=0.99;
                                                            else
                                                                k(season_day+1,zone)=X*Qtot(season_day,zone)^(-Y);
                                                            end
                                                            
                                                            % Calculating lag time for snow and rain
                                                            if season_day >= timelagS % timelagS must be an integer
                                                                Qtot((season_day+1),zone)= Qtot(season_day+1,zone) + Qsnow((season_day+1-timelagS),zone);
                                                            end
                                                            
                                                            if season_day >= timelagP % timelagP must be an integer
                                                                Qtot((season_day+1),zone)= Qtot(season_day+1,zone) + Qrain((season_day+1-timelagP),zone);
                                                            end
                                                            
                                                            % Calculating total streamflow for zone using recession coefficient and lag times
                                                            Qtot(season_day+1,zone)=Qtot(season_day+1,zone)*(1-k(season_day+1,zone))+Qtot(season_day,zone)*k(season_day+1,zone);
                                                            
                                                            % THIS IS THE FINAL STREAMFLOW FOR EACH ZONE WITHIN THE SEASON.
                                                            % END OF ORIGINAL SRM.
                                                           
                                                        end
                                                    end
                                                    Streamflow_estimated_seasonal = 0.0; % Initializing annual estimated streamflow
                                                    Streamflow_estimated_seasonal = sum(Qtot,2); % Adding streamflows from all zones

                                                    NSE_seasonal = Calc_NSE(Streamflow_observed_seasonal,Streamflow_estimated_seasonal);
                                                    KGE_seasonal = Calc_KGE(Streamflow_observed_seasonal,Streamflow_estimated_seasonal);
                                                    DV_seasonal = Calc_DV(Streamflow_observed_seasonal, Streamflow_estimated_seasonal);
                                                    RMSE_seasonal = Calc_RMSE(Streamflow_observed_seasonal, Streamflow_estimated_seasonal);
                                                    Normalized_RMSE_seasonal = Calc_normalized_RMSE(RMSE_seasonal,Streamflow_observed_seasonal);
                                                    MAE_seasonal = Calc_MAE(Streamflow_observed_seasonal,Streamflow_estimated_seasonal);
                                                    
                                                    % If calculated NSE for THIS SET OF PARAMETERS is greater than NSE calculated in PREVIOUS SET OF PARAMETERS
                                                    if NSE_seasonal > str2double(Results(j+1,Season)) 
                                                        Results(j+1,Season) = NSE_seasonal; % Overwrite previous NSE with new NSE
                                                        Results(j+2,Season) = Tcrit; % Overwrite previous Tcrit with new Tcrit
                                                        Results(j+3,Season) = DegDay; % Overwrite previous DegDay with new DegDay
                                                        Results(j+4,Season) = RCsnow; % Overwrite previous RCsnow with new RCsnow
                                                        Results(j+5,Season) = RCrain; % Overwrite previous RCrain with new RCrain
                                                        Results(j+6,Season) = X; % Overwrite previous X with new X
                                                        Results(j+7,Season) = Y; % Overwrite previous Y with new Y
                                                        Results(j+8,Season) = timelagP; % Overwrite previous lagtimeP with new lagtimeP
                                                        Results(j+9,Season) = timelagS; % Overwrite previous lagtimeS with new lagtimeS
                                                        Results(j+10,Season) = Tlapse; % Overwrite previous Tlapse with new Tlapse
                                                        Results(j+11,Season) = Baseflow; % Baseflow will be same, but still overwrite previous baseflow with new baseflow
                                                        Results(j+12,Season) = KGE_seasonal; % Overwrite previous seasonal KGE with new seasonal KGE
                                                        Results(j+13,Season) = DV_seasonal; % Overwrite previous seasonal DV with new seasonal DV
                                                        Results(j+14,Season) = RMSE_seasonal; % Overwrite previous seasonal RMSE with new seasonal RMSE
                                                        Results(j+15,Season) = Normalized_RMSE_seasonal; % Overwrite previous seasonal normalized RMSE with new seasonal normalized RMSE
                                                        Results(j+16,Season) = MAE_seasonal;
                                                        Best_streamflow = Streamflow_estimated_seasonal; % Extract the best streamflow (required to write the final streamflow)
                                                        Best_Qtot = Qtot; % Extract the best Qtot (required for next season's first day)
                                                    end
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
                % By this step, the E-SRM will simulate EVERY parameter combination, and provide the set of parameters that yielded highest NSE.
                % END OF NESTED ITERTOR ALGORITHM.
                
                %%
                % Bifurcate the best streamflow for season (Not used anywhere; but still archives (DOES NOT SAVE) this data for data varification purposes)
                if Season == 1
                    Fall_streamflow = Best_streamflow;
                    Fall_Qtot = Best_Qtot;
                elseif Season == 2
                    Winter_streamflow = Best_streamflow;
                    Winter_Qtot = Best_Qtot;
                elseif Season == 3
                    Spring_streamflow = Best_streamflow;
                    Spring_Qtot = Best_Qtot;
                else
                    Summer_streamflow = Best_streamflow;
                    Summer_Qtot = Best_Qtot;
                end
                
                Qtot_last_day = Best_Qtot(Seasonal_days,:); % Extracts the Qtot of the last day of season (This is the baseflow for next season)
                Final_estimated_streamflow(Begining_of_season:End_of_season) = Best_streamflow; % Append all streamflows to have FINAL streamflow file.
                Season = Season+1; % Increase season number.
            end
            % By this step, the E-SRM will simulate ALL seasons for that year.
            % The Final_streamflow will also keep track of the simulated streamflow for ALL PREVIOUS YEARS.
            % END OF SEASONAL DIVIDER ALGORITHM.
            
            %%
            Annual_estimated_streamflow = 0.0; % Initialize simulated annual streamflow
            Annual_estimated_streamflow = Final_estimated_streamflow(Index_starting_date:Index_ending_date); % Extract annual streamflow from the Final streamflow file.
            
            NSE_annual = Calc_NSE(Annual_observed_streamflow,Annual_estimated_streamflow);
            Results(j+1,6) = ('NSE_annual');
            Results(j+2,6) = NSE_annual; % Write annual NSE
            
            KGE_annual = Calc_KGE(Annual_observed_streamflow,Annual_estimated_streamflow);
            Results(j+1,7) = ('KGE_annual');
            Results(j+2,7) = KGE_annual; % Write annual KGE
            
            DV_annual = Calc_DV(Annual_observed_streamflow,Annual_estimated_streamflow);
            Results(j+1,8) = ('DV_annual');
            Results(j+2,8) = DV_annual; % Write annual DV
            
            RMSE_annual = Calc_RMSE(Annual_observed_streamflow,Annual_estimated_streamflow);          
            Results(j+1,9) = ('RMSE_annual');
            Results(j+2,9) = RMSE_annual; % Write annual RMSE
            
            Normalized_RMSE_annual = Calc_normalized_RMSE(RMSE_annual,Annual_observed_streamflow);
            Results(j+1,10) = ('Normalized_MSE_annual');
            Results(j+2,10) = Normalized_RMSE_annual;
            
            MAE_annual = Calc_MAE(Annual_observed_streamflow,Annual_estimated_streamflow);
            Results(j+1,11) = ('MAE_annual');
            Results(j+2,11) = MAE_annual;
            
            Results(j+1,12) = ('Water_year');
            Results(j+2,12) = Current_year; % Write current water year
            
            Results(j+3:j+16,6:12) = NaN;
            Results(j+1:j+16,5) = string([{'NSE'} {'TCrit'} {'Degday'} {'RCSnow'} {'RCRain'} {'X'} {'Y'} {'TimelagP'} {'TimelagS'} {'Tlapse'} {'Baseflow'} {'KGE'} {'DV'} {'RMSE'} {'Normalized_RMSE'} {'MAE'}]); % Titles for output file (update for every year) for Sheet 1.
            j = j+18; % Used for specifying the location of row for making the 'Results' table
            
        end
        % By this step, the E-SRM will have calculated best seasonal NSE, and corresponding DV and RMSE.
        % By this step, the E-SRM will also have calculated the corresponding annual NSE, DV and RMSE.
        % END OF AUTOMATED BATCH PROCESSING ALGORITHM.
        
        %% Writing in Excel file
        Sheet2_title = [{'Date'} {'Observed streamflow'} {'Estimated streamflow'}]; % Titles for sheet 2.
        Streamflow_sheet = [string(Dates) Streamflow_observed Final_estimated_streamflow]; % Data for Sheet 2.
        Sheet2 = [Sheet2_title;Streamflow_sheet];
        xlswrite(EXCEL,Results,1,sprintf('A1')); % Write in Sheet 1 of the Excel file
        xlswrite(EXCEL,Sheet2,2,sprintf('A1')); % Write in Sheet 2 of the Excel file
    else % If T, P, CDC or streamflow has any NaN value
        fprintf('There is a No Data value present. Please check your Input Data.\n\n');
    end
else % If T, P, CDC and streamflow data have different length
    fprintf('Length of temperature, precipitation, snow cover and streamflow data does not match. Please check your Input Data.\n\n');
end

%% END of Step_3_E_SRM_batch_calibration.m