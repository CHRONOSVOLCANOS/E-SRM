Figure 7 primarily shows the calibration of scenario 1 (2001-2021). It inheently contains
 calibration for scenario 2 (2001-2011) and scenario 3 (odd years between 2001-2021).