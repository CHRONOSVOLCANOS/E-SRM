function date = findadate(day,year)

% LAST UPDATE: 08/14/2024 @ 3.01 AM MDT.
% Function to determine the date of the acquired image from day and year of
% acquisition.

if mod(year, 400) == 0
    leap_year = true;
elseif mod(year, 4) == 0 && mod(year, 100) ~= 0
    leap_year = true;
else
    leap_year = false;
end

if leap_year == true
    if day <= 31
        month = 01;
        day = day;
    elseif day > 31 && day <= 60
        month = 02;
        day = day-31;
    elseif day > 60 && day <= 91
        month = 03;
        day = day - 60;
    elseif day > 91 && day <=121
        month = 04;
        day = day - 91;
    elseif day > 121 && day <=152
        month = 05;
        day = day - 121;
    elseif day > 152 && day <= 182
        month = 06;
        day = day - 152;
    elseif day > 182 && day <= 213
        month = 07;
        day = day - 182;
    elseif day > 213 && day <= 244
        month = 08;
        day = day - 213;
    elseif day > 244 && day <= 274
        month = 09;
        day = day - 244;
    elseif day > 274 && day <= 305
        month = 10;
        day = day - 274;
    elseif day > 305 && day <= 335
        month = 11;
        day = day - 305;
    elseif day > 335 && day <= 366
        month = 12;
        day = day - 335;
    end
    
elseif leap_year == false
    if day <= 31
        month = 01;
        day = day;
    elseif day > 31 && day <= 59
        month = 02;
        day = day-31;
    elseif day > 59 && day <= 90
        month = 03;
        day = day - 59;
    elseif day > 90 && day <=120
        month = 04;
        day = day - 90;
    elseif day > 120 && day <=151
        month = 05;
        day = day - 120;
    elseif day > 151 && day <= 181
        month = 06;
        day = day - 151;
    elseif day > 181 && day <= 212
        month = 07;
        day = day - 181;
    elseif day > 212 && day <= 243
        month = 08;
        day = day - 212;
    elseif day > 243 && day <= 273
        month = 09;
        day = day - 243;
    elseif day > 273 && day <= 304
        month = 10;
        day = day - 273;
    elseif day > 304 && day <= 334
        month = 11;
        day = day - 304;
    elseif day > 334 && day <= 365
        month = 12;
        day = day - 334;
    end
end
day_find = num2str(day);
month_find = num2str(month);
year_find = num2str(year);
date = {[month_find,'-',day_find,'-',year_find]};
%fprintf('Current date is %s-%s-%s.\n',month_find,day_find,year_find);