%% PLEASE CITE THIS PAPER WHEN USING THIS CODE:


% LAST UPDATE: 08/14/2024 @ 6.31 PM MDT.

% Batch processing MODIS 8-day snow cover images to derive the fractional
%   snow cover area.

% The MODIS data must be mosaiked and clipped to the watershed area prior
%   to this process. We used ArcMap ModelBuilder to do so.

% Following MATLAB functions are necessary to run this code:
%   1. Automatic_zonal_bifurcation.m
%   2. excelinput_MODIS8dayCDC_Fall2023
%   2. findadate.m
%   3. leapyear.m

% The mosaicked and clipped MODIS 8-day snow cover data needs to be in a
%   single folder. This code will automatically read all .tif files, derive
%   the fractional snow cover of each day and for each zone, interpolate the 8-day data into
%   daily data by linear interpolation, and save the data in an Excel
%   file.

% Input data required for this code:
%   1. Path and name of the DEM of the entire watershed (in .tif format
%   2. Elevation range (m) (any range; we used 500 m)
%   3. Path of the MODIS 8-day snow cover imagery (.tif)
%   4. Name of the output Excel file

% DUE TO SIZE OF THE MOD10A2 DATASET, THE RAW SNOW COVER DATA COULD NOT BE
%   UPLOADED WITH THE CODE. 

% YOU WILL NEED TO DOWNLOAD MOD10A2 DATASET FROM OCTOBER 1, 2000 TO
%   SEPTEMBER 30, 2021 (FOR TILES h09v04 AND h10v04), EXTRACT
%   Maximum_Snow_Extent, REPROJECT INTO World_Sinusoidal, MOSAIC, RESAMPLE
%   TO 100 M, AND THEN CLIP WITH THE WATERSHED DEM.

% Following data and example will demonstrate the use of this code.
%   1. Run the code.
%   2. Input path and name of the watershed DEM.
%   3. Input the elevation range of 500 m.
%   4. Input the path for MOD12A2 files (all in .tif format). You will need
%       to pre-process the data using the direction stated in CAPS.
%   5. Type the name of the output Excel file.

%% Initialize the model by clearning all memory in this MATLAB interface
clear;
clc;

%% Input alll required data for data processing
DEM_path = input('Please enter the path and name of the DEM: ','s'); % Path and name of the watershed DEM
Elevation_range = input('Please enter the elevation range for your zones (m): '); % Elevation range
SNOW_path = input('Please enter the path of MODIS 8-day snow cover files: ','s'); % Path to MODIS 8-day snow cover images.
EXCEL_output = input('Please enter the output path and name for generated excel file: ','s'); % Name of the final Excel output file.

%% Generate the list of snow images and total number of zones
SNOW_tiff_list = dir(fullfile(SNOW_path,'*.tif'));
snow_length = length(SNOW_tiff_list);

Zones_image = Automatic_zonal_bifurcation(DEM_path,Elevation_range); % function 'Automatic_zonal_bifurcation.m'
% This function returns the zonal bifurcation of the watershed based on DEM
%   and elevation range provided by the user.

Total_Zones = max(max(Zones_image)); % Calculates the total number of zones based on the Zones_image matrix from above.

%% Processing each zone
for Zone = 1:Total_Zones
    EXCEL = excelinput_MODIS8dayCDC_Fall2023(Zone,EXCEL_output); % Calls a function 'excelinput_MODIS8dayCDC_Fall2023.m'
    % This function provides input directory - creates excel file with titles.
    
    fprintf('Processing zone %d.\n\n',Zone);
    Previous_leap = 1; % DO NOT CHANGE. Initializing the leap year condition for the year 2000. Required to correctly place cells in an Excel file.
    Leap_counter = 0; % DO NOT CHANGE. Initializing Leap counter for current zone. Required to correctly place cells in an Excel file.
    Unleap_counter = 0; % DO NOT CHANGE. Initializing Unleap counter for current zone. Required to correctly place cells in an Excel file.
    day_snow_prev_read = 0; % Initializing day number of previous day - to catch missing images.
    Missing_counter = 0; % Calculates how many images are missing. Required to correctly place cells in an Excel file
    
    for i = 1:length(SNOW_tiff_list)
        filename_snow = fullfile(SNOW_path, [SNOW_tiff_list(i).name]);
        SNOW_image = geotiffread(filename_snow);
        if numel(SNOW_image) ~= numel(Zones_image) % Making sure that the DEM and MODIS images are of exactly same size.
            fprintf('The image size is not same. Please check the images. Pausing...\n\n');
            pause;
        end
        snow_name = SNOW_tiff_list(i).name;
        year_snow = str2double(snow_name(10:13)); % Read current year from MOD10A2 image
        day_snow_read = str2double(snow_name(14:16)); % Read current day from MOD10A2 image
        date_snow = findadate(day_snow_read,year_snow); % Calls a function 'findadate.m'
        % This function reads the day number and year from the MODIS 8-day
        %   snow cover data, and correlates that day with the full date in
        %   MM-DD-YYYY format.
        
        fprintf('Processing %s\n\n',snow_name);
        
        x = size(SNOW_image,1); % Number of rows in MOD12A2 image
        y = size(SNOW_image,2); % Number of columns in MOD10A2 image
        
        % Initializing all possible variable values from the MOD10A2 dataset.
        total = 0;
        Miss_pixels = 0;
        NO_decision = 0;
        Night = 0;
        NO_snow = 0;
        lake = 0;
        ocean = 0;
        cloud = 0;
        lake_ice = 0;
        Snow = 0;
        sat = 0;
        fill = 0;
        for m = 1:x
            for n = 1:y
                if double(Zones_image(m,n)) == Zone % Making sure that the current zone is under progress.
                    total = total+1; % Total number of pixels for calculating total zone area.
                    if SNOW_image(m,n) == 0
                        Miss_pixels = Miss_pixels+1; % Missing data - pixel value = 0
                    elseif SNOW_image(m,n) == 1
                        NO_decision = NO_decision+1; % No decision - pixel value = 1
                    elseif SNOW_image(m,n) == 11
                        Night = Night+1; % Night - pixel value = 11
                    elseif SNOW_image(m,n) == 25
                        NO_snow = NO_snow+1; % No snow - pixel value = 25
                    elseif SNOW_image(m,n) == 37
                        lake = lake+1; % Lake - pixel value = 37
                    elseif SNOW_image(m,n) == 39
                        ocean = ocean+1; % Ocean - pixel value = 39
                    elseif SNOW_image(m,n) == 50
                        cloud = cloud+1; % Cloud - pixel value = 50
                    elseif SNOW_image(m,n) == 100
                        lake_ice = lake_ice+1; % Lake ice - pixel value = 100
                    elseif SNOW_image(m,n) == 200
                        Snow = Snow+1; % SNOW - pixel value = 200 -- THIS IS NEEDED FOR FRACTIONAL SNOW COVER CALCULATION.
                    elseif SNOW_image(m,n) == 254
                        sat = sat+1; % Detector saturated - pixel value = 254
                    elseif SNOW_image(m,n) == 255
                        fill = fill+1; % Fill - pixel value = 255
                    end
                end
            end
        end
        
        Leap = leapyear(year_snow); % Calls a function 'leapyear.m'
        % This function reads the year from MOD10A2 image and determines if
        %   the current year is leap year or not.
        
        if day_snow_read == 1 % ONLY for 1st day of year (January 1)
            if Previous_leap == 1
                cell = 8*i+2-8-Leap_counter*2-Unleap_counter*3-2; % Specifying cell location for January 1, if the previous leap was a leap year.
                Leap_counter = Leap_counter+1;
            elseif Previous_leap == 0
                cell = 8*i+2-8-Leap_counter*2-Unleap_counter*3-3; % Specifying cell location for January 1, if the previous leap was NOT a leap year.
                Unleap_counter = Unleap_counter+1;
            end
            Previous_leap = Leap; % Change leap year status of previous leap year to current leap year.
        else
            cell = 8*i+2-8-Leap_counter*2-Unleap_counter*3; % For all days other than January 1.
        end
        cell = cell+ Missing_counter*8;
        
        % Make the data row using the same column indexes as the title in
        %   the function 'excelinput_MODIS8dayCDC_Fall2023.m'.
        Datarow = [date_snow day_snow_read year_snow Miss_pixels/total NO_decision/total Night/total NO_snow/total lake/total ocean/total cloud/total lake_ice/total Snow/total sat/total fill/total];
        
        if i ==1
            xlswrite(EXCEL,Datarow,Zone,sprintf('A%d',cell)); % Write for first day normally.
        else
            if day_snow_read - day_snow_prev_read == 8 || day_snow_read - day_snow_prev_read == -360
                xlswrite(EXCEL,Datarow,Zone,sprintf('A%d',cell)); % If the difference between current and previous days is 8 days, write normally.
            else
                if day_snow_read - day_snow_prev_read > 0 % If the difference between current and previous day is more than 8 days, it means that there is missing data.
                    Missing_counter = Missing_counter + floor((day_snow_read-day_snow_prev_read)/8)-1;
                    cell = cell + day_snow_read - day_snow_prev_read-8; % Account for missing data within one year and leave that many spaces blank. CANNOT ACCOUNT FOR MORE THAN 1 YEAR.
                    xlswrite(EXCEL,Datarow,Zone,sprintf('A%d',cell)); % Write with updated cell list.
%                 else                      % IT IS COMPLICATED TO INDEX BETWEEN CHANGING YEARS.
%                                             I AM HOLDING OFF FOR NOW. 08/14/2024 @ 1.06 PM MDT.
%                     if Previous_leap == 1
%                         cell = cell + 366-day_snow_prev_read + day_snow_read - 6;
%                         xlswrite(EXCEL,Datarow,Zone,sprintf('A%d',cell));
%                     else
%                         cell = cell + 365-day_snow_prev_read + day_snow_read - 5;
%                         xlswrite(EXCEL,Datarow,Zone,sprintf('A%d',cell));
%                     end
                end
            end
        end
        day_snow_prev_read = day_snow_read;
    end % Finish ALL MOD10A2 images before processing further.
    
    current_zone = string(('Sheet'+string(Zone)));
    [Data, titles] = xlsread(EXCEL,current_zone); % Read the same Excel file again after processing all MOD10A2 images for one zone.
    Snow_data = Data(:,11); % Extract column of Snow data (originally column 12 (L)), but when using xlsread, column 11.
    Snow_data_interpolated = zeros(length(Snow_data),1); % Initializing FINAL daily interpolated fractional snow cover data
    Days = Data(:,1); % Extract column of Days data (originally column 2 (B)), but when using xlsread, column 1.
    Days_interpolated = zeros(length(Days),1); % Initializing zeros vector for interpolated Days
    Year = Data(:,2); % Extract column of Year data (originally column 3 (C)), but when using xlsread, column 2.
    Year_interpolated = zeros(length(Year),1); % Initializing zzeros vector  for interpolated Year
    
    % Interpolation from 8-day data to daily data using following code.
    for j = 1:length(Snow_data)-8 % Up to second-to-last Snow data
        if ~isnan(Snow_data(j)) % Check for NO DATA
            if Days(j) ~= 361 % Ignoring last day of acquisition for each year (It is more complex and solved later)
                Snow_data_interpolated(j) = Snow_data(j); % On 1st day of each acquisition, interpolated snow data is real snow data.
                Days_interpolated(j) = Days(j); % On 1st day, interpolated day is real day.
                Year_interpolated(j) = Year(j); % On 1st day, interpolated year is real year.
                Data1 = Snow_data(j); % Read first snow data in sequence.
                Data2 = Snow_data(j+8); % Read second snow data in sequence.
                if ~isnan(Data2) % Making sure Data 2 is not NaN
                    if Data1 > Data2 % If Data 1 is greater, different equation for interpolation.
                        for k = 1:7
                            Interpolation = Data1 - (k)*(Data1-Data2)/8;
                            cell = j+k;
                            Snow_data_interpolated(cell) = Interpolation;
                            Days_interpolated(cell) = Days_interpolated(j)+k;
                            Year_interpolated(cell) = Year_interpolated(j);
                        end
                    elseif Data1 < Data2 % If Data 2 is greater, different equation for interpolation.
                        for k = 1:7
                            Interpolation = Data1 + (k)*(Data2-Data1)/8;
                            cell = j+k;
                            Snow_data_interpolated(cell) = Interpolation;
                            Days_interpolated(cell) = Days_interpolated(j)+k;
                            Year_interpolated(cell) = Year_interpolated(j);
                        end
                    else % If Data 1 and Data 2 are equal, copy data in all middle cells.
                        for k = 1:7
                            Interpolation = Data1;
                            cell = j+k;
                            Snow_data_interpolated(cell) = Interpolation;
                            Days_interpolated(cell) = Days_interpolated(j)+k;
                            Year_interpolated(cell) = Year_interpolated(j);
                        end
                    end
                else % % If Data2 is NaN, it means that there is missing data in Data2. Thus we need to go to next available data to interpolate all values in between
                    Jump_counter = 0;
                    while isnan(Data2)
                        Jump_counter = Jump_counter + 1;
                        Data2 = Snow_data(Jump_counter*8+j+8);
%                         pause;
                    end
                    Total_data_difference = Jump_counter*8+8;
                    
                    if Data1 > Data2 % If Data 1 is greater, different equation for interpolation.
                        for k = 1:(Total_data_difference-1)
                            Interpolation = Data1 - (k)*(Data1-Data2)/Total_data_difference;
                            cell = j+k;
                            Snow_data_interpolated(cell) = Interpolation;
                            Days_interpolated(cell) = Days_interpolated(j)+k;
                            Year_interpolated(cell) = Year_interpolated(j);
                        end
                    elseif Data1 < Data2 % If Data 2 is greater, different equation for interpolation.
                        for k = 1:(Total_data_difference-1)
                            Interpolation = Data1 + (k)*(Data2-Data1)/Total_data_difference;
                            cell = j+k;
                            Snow_data_interpolated(cell) = Interpolation;
                            Days_interpolated(cell) = Days_interpolated(j)+k;
                            Year_interpolated(cell) = Year_interpolated(j);
                        end
                    else % If Data 1 and Data 2 are equal, copy data in all middle cells.
                        for k = 1:(Total_data_difference-1)
                            Interpolation = Data1;
                            cell = j+k;
                            Snow_data_interpolated(cell) = Interpolation;
                            Days_interpolated(cell) = Days_interpolated(j)+k;
                            Year_interpolated(cell) = Year_interpolated(j);
                        end
                    end
                    j = j + 8*Jump_counter + 8 - 1;
                    continue;
                end
            else % If last data acquisition for year (day 361), solved here.
                Leap_status = leapyear(Year(j)); % Calls function 'leapyear.m' to check if current year is leap year.
                Days_interpolated(j) = Days(j);
                Year_interpolated(j) = Year(j);
                Snow_data_interpolated(j) = Snow_data(j);
                if Leap_status == 1 % If current year IS leap year
                    Data1 = Snow_data(j); % Snow data of day 361 of current year
                    Data2 = Snow_data(j+6); % Snow data of day 1 of next year
                    if Data1 > Data2 % If Data 1 is greater, different equation for interpolation.
                        for k = 1:5
                            Interpolation = Data1 - (k)*(Data1-Data2)/6;
                            cell = j+k;
                            Snow_data_interpolated(cell) = Interpolation;
                            Days_interpolated(cell) = Days_interpolated(j)+k;
                            Year_interpolated(cell) = Year_interpolated(j);
                        end
                    elseif Data1 < Data2 % If Data 2 is greater, different equation for interpolation.
                        for k = 1:5
                            Interpolation = Data1 + (k)*(Data2-Data1)/6;
                            cell = j+k;
                            Snow_data_interpolated(cell) = Interpolation;
                            Days_interpolated(cell) = Days_interpolated(j)+k;
                            Year_interpolated(cell) = Year_interpolated(j);
                        end
                    else % If Data 1 and Data 2 are equal, copy data in all middle cells.
                        for k = 1:5
                            Interpolation = Data1;
                            cell = j+k;
                            Snow_data_interpolated(cell) = Interpolation;
                            Days_interpolated(cell) = Days_interpolated(j)+k;
                            Year_interpolated(cell) = Year_interpolated(j);
                        end
                    end
                else % If current year IS NOT leap year
                    Data1 = Snow_data(j); % Snow data of day 361 of current year
                    Data2 = Snow_data(j+5); % Snow data of day 1 of next year
                    if Data1 > Data2 % If Data 1 is greater, different equation for interpolation.
                        for k = 1:4
                            Interpolation = Data1 - (k)*(Data1-Data2)/5;
                            cell = j+k;
                            Snow_data_interpolated(cell) = Interpolation;
                            Days_interpolated(cell) = Days_interpolated(j)+k;
                            Year_interpolated(cell) = Year_interpolated(j);
                        end
                    elseif Data1 < Data2 % If Data 2 is greater, different equation for interpolation.
                        for k = 1:4
                            Interpolation = Data1 + (k)*(Data2-Data1)/5;
                            cell = j+k;
                            Snow_data_interpolated(cell) = Interpolation;
                            Days_interpolated(cell) = Days_interpolated(j)+k;
                            Year_interpolated(cell) = Year_interpolated(j);
                        end
                    else % If Data 1 and Data 2 are equal, copy data in all middle cells.
                        for k = 1:4
                            Interpolation = Data1;
                            cell = j+k;
                            Snow_data_interpolated(cell) = Interpolation;
                            Days_interpolated(cell) = Days_interpolated(j)+k;
                            Year_interpolated(cell) = Year_interpolated(j);
                        end
                    end
                end
            end
        end
    end
    cellRef = sprintf('P%d',1);
    xlswrite(EXCEL,{'Interpolated snow cover'},Zone,cellRef);
    cellRef = sprintf('P%d',2);
    xlswrite(EXCEL,Snow_data_interpolated,Zone,cellRef); % Write interpolated fractional snow cover data in column P.
    cellRef = sprintf('B%d',2);
    xlswrite(EXCEL,Days_interpolated,Zone,cellRef); % Overwrite interpolated days in column B.
    cellRef = sprintf('C%d',2);
    xlswrite(EXCEL,Year_interpolated,Zone,cellRef); % Overright interpolated year in column C.
end