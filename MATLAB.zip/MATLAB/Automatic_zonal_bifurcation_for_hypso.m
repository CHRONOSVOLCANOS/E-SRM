function [Zone_image,final,DEM] = Automatic_zonal_bifurcation_for_hypso(DEM_path,Elevation_range,x_res,y_res)

% LAST UPDATE: 08/14/2024 @ 2.06 AM MDT
[DEM, R] = geotiffread(DEM_path); % Read the complete watershed DEM file with metadata.
info = geotiffinfo(DEM_path); % Read geotiffinfo of same geotiff. Required to write a geotiff upon completion of this function.

rows = size(DEM,1);
columns = size(DEM,2);

Zone_image = zeros(rows,columns); % Zone raster (Same size as total watershed DEM)

Minimum_elevation = min(min(DEM(DEM>0))); % Minimum elevation of watershed DEM
Maximum_elevation = max(max(DEM(DEM<10000))); % Maximum elevation of watershed DEM

Total_watershed_area = numel(DEM(DEM >= Minimum_elevation & DEM <= Maximum_elevation))*x_res*y_res/1e6; % Calculate total watershed area.
Zone_area = [];
Zone = 0; % Initialize zones
for elevation = Minimum_elevation:Maximum_elevation
    if elevation < Maximum_elevation % This will check EACH elevation increament between minimum and maximum elevation.
        if rem(elevation,Elevation_range) == 0 % This will make sure that consideration of each zone will be stop at the upper limit of the elevation range.
            Zone = Zone + 1;
            if Zone == 1
                [row_zone, col_zone] = find(DEM >= Minimum_elevation & DEM <= elevation);
            else
                [row_zone, col_zone] = find(DEM > Previous_max_elevation & DEM <= elevation);
            end
            for i = 1:length(row_zone)
                Zone_image(row_zone(i),col_zone(i)) = Zone;
            end
            Previous_max_elevation = elevation;
            Zone_area(Zone,1) = Zone;
            Zone_area(Zone,2) = numel(Zone_image(Zone_image == Zone));
        end
    elseif elevation == Maximum_elevation
        Zone = Zone+1;
        if Zone == 1
            [row_zone, col_zone] = find(DEM >= Minimum_elevation & DEM <= elevation);
        else
            [row_zone, col_zone] = find(DEM > Previous_max_elevation & DEM <= elevation);
        end
        for i = 1:length(row_zone)
            Zone_image(row_zone(i),col_zone(i)) = Zone;
        end
        Zone_area(Zone,1) = Zone;
        Zone_area(Zone,2) = numel(Zone_image(Zone_image == Zone));
    end
end
Zone_area(:,2) = Zone_area(:,2)*x_res*y_res/1e6; % Calculate zone area.
Zone_area(:,3) = Zone_area(:,2)/Total_watershed_area; % Calculate zone area fraction w.r.t. total watershed area.
Zone_area = num2cell(Zone_area);
Title = [{'Zone ID'} {'Area (square km)'} {'Area_fraction'}];
final = [Title; Zone_area];
geotiffwrite('Zones_from_MATLAB.tif',Zone_image,R,'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);