function [Zone_image] = Automatic_zonal_bifurcation(DEM_path,Elevation_range)

% LAST UPDATE: 08/14/2024 @ 2.51 AM MDT
DEM = geotiffread(DEM_path); % Read the complete watershed DEM file with metadata.

rows = size(DEM,1);
columns = size(DEM,2);

Zone_image = zeros(rows,columns); % Zone raster (Same size as total watershed DEM)

Minimum_elevation = min(min(DEM(DEM>0))); % Minimum elevation of watershed DEM
Maximum_elevation = max(max(DEM(DEM<10000))); % Maximum possible elevation of watershed DEM

Zone = 0; % Initialize zones
for elevation = Minimum_elevation:Maximum_elevation
    if elevation < Maximum_elevation % This will check EACH elevation increament between minimum and maximum elevation.
        if rem(elevation,Elevation_range) == 0 % This will make sure that consideration of each zone will be stop at the upper limit of the elevation range.
            Zone = Zone + 1;
            if Zone == 1
                [row_zone, col_zone] = find(DEM >= Minimum_elevation & DEM <= elevation);
            else
                [row_zone, col_zone] = find(DEM > Previous_max_elevation & DEM <= elevation);
            end
            for i = 1:length(row_zone)
                Zone_image(row_zone(i),col_zone(i)) = Zone;
            end
            Previous_max_elevation = elevation;
        end
    elseif elevation == Maximum_elevation
        Zone = Zone+1;
        if Zone == 1
            [row_zone, col_zone] = find(DEM >= Minimum_elevation & DEM <= elevation);
        else
            [row_zone, col_zone] = find(DEM > Previous_max_elevation & DEM <= elevation);
        end
        for i = 1:length(row_zone)
            Zone_image(row_zone(i),col_zone(i)) = Zone;
        end
    end
end