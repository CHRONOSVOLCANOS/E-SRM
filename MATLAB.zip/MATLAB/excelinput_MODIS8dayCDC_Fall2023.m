function EXCEL_output = excelinput_MODIS8dayCDC_Fall2023(noofsheet,EXCEL_output)

% LAST UPDATE: 08/14/2024 @ 2.53 AM MDT.
clc;
title2 = {'Date'};
xlRange = sprintf('A%d',1);
xlswrite(EXCEL_output,title2,noofsheet,xlRange);

title2 = {'Day'};
xlRange = sprintf('B%d',1);
xlswrite(EXCEL_output,title2,noofsheet,xlRange);

title2 = {'Year'};
xlRange = sprintf('C%d',1);
xlswrite(EXCEL_output,title2,noofsheet,xlRange);

title2 = {'Missing_data'};
xlRange = sprintf('D%d',1);
xlswrite(EXCEL_output,title2,noofsheet,xlRange);

title3 = {'No_decesion'};
xlRange = sprintf('E%d',1);
xlswrite(EXCEL_output,title3,noofsheet,xlRange);

title2 = {'Night'};
xlRange = sprintf('F%d',1);
xlswrite(EXCEL_output,title2,noofsheet,xlRange);

title2 = {'No_snow'};
xlRange = sprintf('G%d',1);
xlswrite(EXCEL_output,title2,noofsheet,xlRange);

title2 = {'Lake'};
xlRange = sprintf('H%d',1);
xlswrite(EXCEL_output,title2,noofsheet,xlRange);

title2 = {'Ocean'};
xlRange = sprintf('I%d',1);
xlswrite(EXCEL_output,title2,noofsheet,xlRange);

title2 = {'Cloud'};
xlRange = sprintf('J%d',1);
xlswrite(EXCEL_output,title2,noofsheet,xlRange);

title2 = {'Lake_Ice'};
xlRange = sprintf('K%d',1);
xlswrite(EXCEL_output,title2,noofsheet,xlRange);

title2 = {'Snow'};
xlRange = sprintf('L%d',1);
xlswrite(EXCEL_output,title2,noofsheet,xlRange);

title2 = {'Detector_saturated'};
xlRange = sprintf('M%d',1);
xlswrite(EXCEL_output,title2,noofsheet,xlRange);

title2 = {'Fill'};
xlRange = sprintf('N%d',1);
xlswrite(EXCEL_output,title2,noofsheet,xlRange);