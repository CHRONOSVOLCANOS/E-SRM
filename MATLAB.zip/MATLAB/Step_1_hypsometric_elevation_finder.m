%% PLEASE CITE THIS PAPER WHEN USING THIS CODE:


% LAST UPDATE: 08/15/2024 @ 10.52 PM MDT

% Calculating the total area, fractional area, and hypsometric elevation of
%   each elevation zone in a watershed

% The hypsometric elevation is the elevation, above and below which, the
%   area of the watershed is equal. This program calculates the nearest
%   possible integer value of the actual hypsometric elevation.

% Following function is required to run the code:
%   Automatic_zonal_bifurcation_for_hypso.m

% Input data required for rhis code:
%   1. Path and name of the watershed DEM (in .tif format)
%   2. Elevation range (any range; we used 500 m).
%   3. Name of the output Excel file
%   4. Resolution in x side in meters (Cell size x) - Can be obtained through metadata in ArcMap
%   5. Resolution in y side in meters (Cell size y) - Can be obtained through metadata in ArcMap

% Following data and example will demonstrate the use of this code.
%   1. Run the code.
%   2. Input path and name of the watershed DEM.
%   3. Input the elevation range of 500 m.
%   4. Type the path and name of the output Excel file.
%   5. Find the cell size x (using ArcMap or any GIS software) and input.
%   6. Find the cell size y (using ArcMap or any GIS software) and input

%% Initialize the model by clearning all memory in this MATLAB interface

clc;
clear;

%% Read all the input .tif files and provide name of output Excel file
DEM_path = input('Please enter the path and name of the DEM: ','s');
Elevation_range = input('Please enter the elevation range for your zones (m): ');
excel_output = input('Please input the output path and name for generated excel file. ','s');
x_res = input('Please enter the resolution on x side (Cell size x) (m): ');
y_res = input('Please enter the resolution on y side (Cell size y) (m): ');

[Zone_image,Zone_area,DEM] = Automatic_zonal_bifurcation_for_hypso(DEM_path,Elevation_range,x_res,y_res);

Zone_max = max(max(Zone_image));
Hypso_list = [];
%% Batch processing each zone
for x = 1:Zone_max
    [row_zone, col_zone] = find(Zone_image == x); % Find all pixel locations with current zone value
    DEM_zone = DEM(sub2ind(size(DEM),row_zone,col_zone)); % Find locations in the DEM with current zone value
    min_zone_elevation = min(DEM_zone);
    max_zone_elevation = max(DEM_zone);
    Zone_pixels = numel(DEM_zone);
    for elevation = min_zone_elevation:max_zone_elevation % This will check each elevation increament between minimum and maximum zone elevation.
            area_lower = 0;
        for i = 1:Zone_pixels
            if DEM_zone(i) < elevation
                area_lower = area_lower+1;
            end
        end
        if area_lower < 0.5*Zone_pixels % If number of pixels are less than half of total zone pixels, continue to next elevation increament.
        elseif area_lower >= (0.5*Zone_pixels) % If number of pixels surpass or are equal to the half of total zone pixels, that is the hypsometric elevation.
            Hypso_list(x,1) = elevation;
            break;
        end
    end
end

Hypso_list = num2cell(Hypso_list);
title = {'Hypsometric Elevation'};
final_hypso = [title; Hypso_list];
final_table = [Zone_area final_hypso];
xlswrite(excel_output,final_table,'Sheet1');