function NSE = Calc_NSE(observed_streamflow, estimated_streamflow)

Average_observed = mean(observed_streamflow);

Obs_Est = observed_streamflow - estimated_streamflow;
Obs_Avg = observed_streamflow - Average_observed;

NSE = 1- (sum(Obs_Est.^2)/sum(Obs_Avg.^2));