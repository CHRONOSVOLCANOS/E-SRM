function Normalized_RMSE = Calc_normalized_RMSE(RMSE,observed_streamflow)

Normalized_RMSE = RMSE/(max(observed_streamflow) - min(observed_streamflow));