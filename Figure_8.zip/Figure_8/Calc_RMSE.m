function RMSE = Calc_RMSE(observed_streamflow, estimated_streamflow)

abs_diff = observed_streamflow - estimated_streamflow;
abs_diff_square = abs_diff.^2;

RMSE = sqrt(mean(abs_diff_square));