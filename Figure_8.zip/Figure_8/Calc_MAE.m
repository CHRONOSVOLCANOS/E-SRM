function MAE = Calc_MAE(observed_streamflow, estimated_streamflow)

abs_diff = abs(observed_streamflow - estimated_streamflow);

MAE = mean(abs_diff);