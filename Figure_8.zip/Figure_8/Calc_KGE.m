function KGE = Calc_KGE(observed_streamflow, estimated_streamflow)

r = corr(observed_streamflow,estimated_streamflow);

sigma_o = std(observed_streamflow);
sigma_s = std(estimated_streamflow);
alpha = sigma_s/sigma_o;

mu_o = mean(observed_streamflow);
mu_s = mean(estimated_streamflow);
beta = mu_s/mu_o;

KGE = 1 - sqrt((r - 1)^2 + (alpha - 1)^2 + (beta - 1)^2);