function simpleHalfViolin(data, xCenter, color, side)
    % Kernel density
    [f, xi] = ksdensity(data);
    f = f / max(f) * 0.3;  % Scale for width

    % Define half violin based on side
    switch side
        case 'left'
            x = [xCenter - f, fliplr(xCenter * ones(size(f)))];
        case 'right'
            x = [xCenter * ones(size(f)), fliplr(xCenter + f)];
        otherwise
            error('Side must be ''left'' or ''right''.');
    end
    y = [xi, fliplr(xi)];

    fill(x, y, color, 'FaceAlpha',0.7, 'EdgeColor','k', 'LineWidth',1,'FaceAlpha',1);
end