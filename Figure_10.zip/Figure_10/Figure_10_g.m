clc;
clear;
clf;
close all;

EXCEL = 'Figure_10_a_g.xlsx';
[beforeData,textdata] = xlsread(EXCEL,'Figure 10 g_obs');
beforeData = beforeData(:,2:end);

afterData = xlsread(EXCEL,'Figure 10 g_regcor');
afterData = afterData(:,2:end);

textdata = textdata(1,2:end);
numMetrics = size(beforeData,2);

% % % Colors: lighter for before, darker for after
colorsBefore = [0.5 0.8 1; 0.6 1 0.6; 1 0.8 0.7; 1 1 0.7; 0.9 0.7 1; 0.7 1 1];
colorsAfter  = [0.2 0.4 0.6; 0 0.5 0; 0.8 0.3 0; 0.8 0.8 0; 0.6 0 0.8; 0 0.7 0.7];

% Create a single figure for all the metrics (in a single row)
figure;

% Create subplots in a single row
for i = 1:numMetrics
    % Create a subplot for each metric in a single row
    h = subplot(1, numMetrics, i);

    pos = get(h, 'Position');
    pos(1) = pos(1) + 0.05*(i-1); % shift each subplot rightwards
    set(h, 'Position', pos);
    hold on;

    % Ensure the X-axis values for the half-violins are placed correctly
    % Half violin for Before (Left side)
    simpleHalfViolin(beforeData(:,i), 0, colorsBefore(i,:), 'left');

    % Half violin for After (Right side)
    simpleHalfViolin(afterData(:,i), 0, colorsAfter(i,:), 'right');

    % Median lines
    medB = median(beforeData(:,i));
    medA = median(afterData(:,i));
    plot([0-0.3 0], [medB medB], 'Color', 'k', 'LineWidth', 1);
    plot([0 0+0.3], [medA medA], 'Color', 'k', 'LineWidth', 1, 'LineStyle','--');

    % % Separator lines between metrics
    % xline(0, 'k-');

    % Set Y-limits individually for each plot
    minVal = min([beforeData(:,i); afterData(:,i)]);
    maxVal = max([beforeData(:,i); afterData(:,i)]);
    ylim([minVal, maxVal]);

    % Add horizontal lines at min and max data points
    plot([-0.3, 0.3], [minVal,minVal], 'k-', 'LineWidth', 1);  % Min horizontal line
    plot([-0.3, 0.3], [maxVal,maxVal], 'k-', 'LineWidth', 1);  % Max horizontal line

% Add median values as text annotations
    text(-0.15, medB, sprintf('%.2f', medB), 'Color', 'k', 'VerticalAlignment', 'top', 'HorizontalAlignment', 'center', 'FontSize', 12);
    text(0.15, medA, sprintf('%.2f', medA), 'Color', 'k', 'VerticalAlignment', 'top', 'HorizontalAlignment', 'center', 'FontSize', 12);

    % % Title and labels
    % Replace numbers with superscripts
    textdata{1,i} = regexprep(textdata{1,i}, '(\d+)', '^{\3}');

    % Replace 'DV' with subscripted 'D_{V}'
    if strcmp(textdata{1,i}, 'DV (%)')
        textdata{1,i} = 'D_{V} (%)';
    end

    % Set the title with TeX interpreter
    title(textdata{1,i}, 'Interpreter', 'tex', 'FontSize',14)

    xticks([1 2]);
    xticklabels({'Before', 'After'});
    box on;

    % Adjust layout to make the subplots fit nicely in a single row
    ax = gca; % Get current axis
    ax.Position = [0.05 + (i-1)*0.15, 0.2, 0.12, 0.65]; % Adjust width to fit in single row

    hold on
p1 = patch(NaN, NaN, [0.7 0.7 0.7], 'FaceAlpha', 0.6, 'EdgeColor', 'k'); % Light color (Before)
p2 = patch(NaN, NaN, [0.3 0.3 0.3], 'FaceAlpha', 0.6, 'EdgeColor', 'k'); % Dark color (After)

% Dummy lines for medians
h1 = plot(nan, nan, '-', 'Color', [0 0 0], 'LineWidth', 2); % solid line for before
h2 = plot(nan, nan, '--', 'Color', [0 0 0], 'LineWidth', 2); % dashed line for after

end
lgd = legend([p1, p2, h1, h2], ...
    {'Violin plot using directly observed streamflow', 'Violin plot using regulation-corrected streamflow', 'Median using directly observed streamflow', 'Median using regulation-corrected streamflow'}, ...
    'NumColumns',2);

lgd.Box = 'off';
lgd.FontSize = 14;

% Manually position below all subplots
set(lgd,'Units','normalized','Position',[0.35 0.1 0.3 0.05]);